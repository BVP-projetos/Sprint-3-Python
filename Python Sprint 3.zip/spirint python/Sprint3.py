import pandas as pd  # Biblioteca para trabalhar com dataframes, organizando e permitindo a simplificação do código | Implementação do Código
import random  # Biblioteca para gerar números aleatórios


# Função para exibir o menu principal
def exibir_menu():
    print("\nBem-vindo ao Interativo Fórmula E!")
    print("1. Ver informações sobre a Fórmula E")
    print("2. FanBoosts disponíveis!")                                           # Implementação do Código
    print("3. Participar de Quiz interativo")
    print("4. Assistir a um vídeo sobre a Fórmula E")
    print("5. Ver notícias recentes")
    print("6. Ver informações das Equipes")                                     # Implementação do Código
    print("7. Ver quantidade de Corridas e Pódios de cada Equipe")              # Implementação do Código
    print("8. Ver estatísticas dos pilotos")
    print("9. Ver estatísticas dos carros")
    print("10. Enviar sugestões")
    print("11. Redes sociais")                                                  # Implementação do Código
    print("12. Sair")


# Função para exibir informações sobre a Fórmula E
def exibir_informacoes():
    informacoes = """
    A Fórmula E é uma categoria de automobilismo organizada pela Federação Internacional de Automobilismo (FIA), onde todos os carros são elétricos.
    O campeonato teve início em 2014 e tem como objetivo promover a sustentabilidade e a inovação tecnológica no setor automobilístico.
    A Fórmula E é conhecida por suas corridas emocionantes em circuitos urbanos de todo o mundo, trazendo a ação diretamente para as cidades.
    Além das corridas, a Fórmula E também foca na conscientização sobre as mudanças climáticas e a importância da energia renovável.
    """
    print(informacoes)


# Função para o Quiz interativo
def quiz_interativo():
    perguntas = [
        {"pergunta": "Em que ano a Fórmula E começou?", "resposta": "2014"},
        {"pergunta": "Qual é o objetivo principal da Fórmula E?", "resposta": "sustentabilidade"},
        {"pergunta": "Que tipo de carros são usados na Fórmula E?", "resposta": "elétricos"}
    ]

    acertos = 0
    for pergunta in perguntas:
        resposta = input(f"{pergunta['pergunta']} ")
        if resposta.lower() == pergunta["resposta"].lower():
            acertos += 1
            print("Correto!")
        else:
            print(f"Errado! A resposta correta é: {pergunta['resposta']}")

    print(f"Você acertou {acertos} de {len(perguntas)} perguntas.")


# Função para simular a exibição de um vídeo
def assistir_video():
    print(
        "Clique no link a seguir para mais informações sobre a Fórmula E: https://youtu.be/kgTHO0kNOpc?si=cSr_UFJjZs5MKbD4")


# Função para exibir notícias recentes
def ver_noticias_recentes():
    noticias = [
        "Pela primeira vez, Tóquio sediará uma corrida de Fórmula E em 2024, prometendo uma adição eletrizante ao calendário da série.",
        "A Fórmula E retorna a Portland com corridas consecutivas e um festival para os fãs, com música ao vivo, arenas de jogos e sessões de autógrafos.",
        "O novo carro Gen3 Evo, projetado para melhor desempenho e sustentabilidade, fará sua estreia competitiva nesta temporada.",
        "A temporada 2024 contará com um recorde de 16 rodadas, com corridas em locais icônicos como Mônaco, Berlim e Londres."
    ]

    print("\nNotícias Recentes:")
    for noticia in noticias:
        print(f"- {noticia}")


# Função para exibir estatísticas dos pilotos
def ver_estatisticas_pilotos():
    pilotos = {
        "Piloto Jean-Éric Vergne": {"vitórias": 10, "poles": 14, "pódios": 25},
        "Piloto Sam Bird": {"vitórias": 11, "poles": 5, "pódios": 12},
        "Piloto Stoffel Vandoorne": {"vitórias": 3, "poles": 8, "pódios": 15},
    }

    print("\nEstatísticas dos Pilotos:")
    for piloto, stats in pilotos.items():
        print(f"{piloto} - Vitórias: {stats['vitórias']}, Poles: {stats['poles']}, Pódios: {stats['pódios']}")


# Função para exibir estatísticas dos carros
def ver_estatisticas_carros():
    carros = {
        "Carro Audi e-tron FE07": {"velocidade_maxima": "240 km/h", "aceleracao": "0-100 km/h em 2.8s",
                                   "autonomia": "45 minutos de corrida"},
        "Carro Jaguar I-TYPE 5": {"velocidade_maxima": "280 km/h", "aceleracao": "0-100 km/h em 2.8s",
                                  "autonomia": "45 minutos de corrida"},
        "Carro DS E-TENSE FE21": {"velocidade_maxima": "250 km/h", "aceleracao": "0-100 km/h em 2.8s",
                                  "autonomia": "45 minutos de corrida"},
    }
    print("\nEstatísticas dos Carros:")
    for carro, stats in carros.items():
        print(
            f"{carro} - Velocidade Máxima: {stats['velocidade_maxima']}, Aceleração: {stats['aceleracao']}, Autonomia: {stats['autonomia']}")


# Função para participação do usuário no FanBoost, aumentando a interatividade do usuário com o código, utilizando match case e import random | Implementação do Código
def fan_boost():
    print("1. São Paulo")
    print("2. México")
    print("3. Jeddah")
    print("4. Jeddah")
    print("5. TBC")
    print("6. Miami")
    print("7. Mônaco")

    porcentagem = random.randint(0, 100)
    fanboost = int(input('Selecione o GrandPrix para FanBoost: '))

    match fanboost:
        case 1 | 2 | 3 | 4 | 6:
            print(f'Está disponível {porcentagem}% de FanBoost para a prova.')
        case 5:
            print(f'FanBoost disponível após definição da prova.')
        case _:
            print('FanBoost não disponível.')

# Função para enviar sugestões
def enviar_sugestoes():
    input("Digite sua sugestão para melhorar a Fórmula E: ")
    print("Obrigado pela sua sugestão! Vamos analisá-la com carinho.")

# Função para exibir informações das equipes de maneira organizada utilizando bilbioteca pandas | Implementação do Código
def dados_equipes():
    equipes = {
        'Equipes': ['ABT Cupra','Andretti Formula E','DS Penske','Envision Racing','ERT Formula E Team','Jaguar TCS Racing','Mahindra Racing',
                    'Maserati MSG Racing','Neon McLaren Formula E','Nissan Formula E Team', 'Tag Heuer Porsche'],
        'Pilotos': ['Lucas Di Grassi e Nico Muller','Jake Dennis e Norman Nato', 'Jean-Éric Vergne e Stoffel Vandoorne', 'Robin Frijns e Sébastien Buemi',
                    'Dan Ticktum e Sérgio Sette Câmara', 'Mitch Evans e Nick Cassidy', 'Edoardo Mortara e Nyck De Vries', 'Jehan Daruvala e Maximilian Gunther',
                    'Jake Hughes e Sam Bird', 'Oliver Rowland e Sacha Fenestraz', 'Pascal Wehrlein e Antônio Felix Da Costa'],
    }

    df = pd.DataFrame(equipes)
    print(df)


# Função para exibir quantidade de corridas e pódios de cada equipe aumentando a informação das equipes utilizando bilbioteca pandas | Implementação do Código
def podios():
    dados = {
    'Pódios': ['ABT Cupra - 47', 'Andretti Formula E - 11', 'DS Penske - 3', 'Envision Racing - 16', 'ERT Formula E Team - 2', 'Jaguar TCS Racing - 16', 'Mahindra Racing - 5',
        'Maserati MSG Racing - 10', 'Neon McLaren Formula E - 8', 'Nissan Formula E Team - 19', 'Tag Heuer Porsche - 12'],
    'Corridas': [115, 32, 132, 132, 132, 111, 131, 132, 87, 132, 74]
    }
    df = pd.DataFrame(dados)
    print(df)


# Função para exibir redes sociais enviando links para aumentar a interatividade com os usuários utilizando biblioteca pandas | Implementação do Código
def redes_sociais():
    aplicativos = {
        'Redes Sociais': ['Instagram', 'Youtube', 'Facebook', 'TikTok'],
        'Seguidores': ['1.2 milhão', '825 mil', '1.5 milhão', '1 milhão'],
    }

    df = pd.DataFrame(aplicativos)
    print(df)
    print('Links:')
    print('Site: https://www.fiaformulae.com/pt-br')
    print('Instagram: https://www.instagram.com/fiaformulae/')
    print('Youtube: https://www.youtube.com/channel/UC-DuRqsBQOEk_5o1q4Ze-Fg')
    print('Facebook: https://www.facebook.com/fiaformulae/')
    print('TikTok: https://www.tiktok.com/@fiaformulae')


# Função principal
def main():
    while True:
        exibir_menu()
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            exibir_informacoes()
        elif opcao == "2":          # Implementação do Código
            fan_boost()
        elif opcao == "3":
            quiz_interativo()
        elif opcao == "4":
            assistir_video()
        elif opcao == "5":
            ver_noticias_recentes()
        elif opcao == "6":
            dados_equipes()         # Implementação do Código
        elif opcao == "7":          # Implementação do Código
            podios()
        elif opcao == "8":
            ver_estatisticas_pilotos()
        elif opcao == "9":
            ver_estatisticas_carros()
        elif opcao == "10":
            enviar_sugestoes()
        elif opcao == "11":
            redes_sociais()   # Implementação do Código
        elif opcao == "12":
            print("Obrigado por participar! Até a próxima.")
            break
        else:
            print("Opção inválida! Tente novamente.")

 # Execução do programa
if __name__ == "__main__":
    main()